find -name NOTES -exec rm -rf {} \;
mkdir cleaned_data
find data/ -type f -print0 | xargs -0 mv -t cleaned_data/
find cleaned_data/ -type f -print0 | xargs -0 -I{} mv "{}" "{}".txt

